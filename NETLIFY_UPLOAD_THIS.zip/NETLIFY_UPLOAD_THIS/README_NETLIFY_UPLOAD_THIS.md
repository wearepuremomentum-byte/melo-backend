# NETLIFY_UPLOAD_THIS

Upload this folder to GitHub and connect GitHub to Netlify.

Important: If you need ARIA Anthropic AI to work, use GitHub deploy or Netlify CLI so the Netlify Function deploys.

Netlify settings:

Build command: blank
Publish directory: .

Environment variables:
ANTHROPIC_API_KEY=sk-ant-...
ANTHROPIC_MODEL=claude-sonnet-4-20250514
