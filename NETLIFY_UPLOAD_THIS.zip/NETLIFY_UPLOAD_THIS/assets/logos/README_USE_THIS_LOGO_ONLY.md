# Pure Meditation Social Logos — Official Photo Only

Source used: `/home/user/uploads/Pure Meditation.png`

The previous generated logo designs were deleted.
These files use ONLY the attached Pure Meditation photo, resized for each platform.
No extra graphics, text, icons, gradients, or alternate logo designs were added.

## Platform Files

TikTok:
- tiktok_logo_200x200.png

Facebook:
- facebook_logo_320x320.png

Instagram:
- instagram_logo_320x320.png

YouTube:
- youtube_logo_800x800.png

Threads:
- threads_logo_320x320.png

Pinterest:
- pinterest_logo_600x600.png

Universal high-res profile:
- profile_logo_1080x1080.png

Master files:
- pure_meditation_logo_original_square.png
- pure_meditation_logo_master_2048.png

Recommended universal upload:
- profile_logo_1080x1080.png

If a platform crops the image into a circle, use the same file anyway. This keeps the brand consistent across every account.
